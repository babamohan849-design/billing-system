
export interface Service {
  id: string;
  nameTa: string;
  nameFr: string;
  price: number;
}

export interface BillItem extends Service {
  qty: number;
  total: number;
}

export interface Bill {
  id: string;
  billNumber: string;
  date: string;
  
  // Customer Info
  customer: string;
  customerEmail?: string;
  
  // Vehicle Info
  vehicleNo?: string; // License Plate
  vehicleModel?: string; // e.g., Toyota Corolla
  
  // Meta
  type: 'invoice' | 'quote'; // Invoice or Estimate
  status: 'paid' | 'pending'; 
  
  taxRate: number;
  notes: string;
  subTotal: number;
  taxAmount: number;
  total: number;
  items: BillItem[];
}

export interface Expense {
  id: string;
  titleTa: string;
  typeTa: string;
  amount: number;
  date: string;
  notes: string;
}

export interface Appointment {
  id: string;
  customer: string;
  phone: string;
  vehicleNo: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  service: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
}

export interface Company {
  name: string;
  address: string;
  email: string;
  phone: string;
  logo: string | null;
}

export interface AppData {
  services: Service[];
  expenses: Expense[];
  bills: Bill[];
  appointments: Appointment[];
  company: Company;
}

export type Tab = 'dashboard' | 'billing' | 'services' | 'expenses' | 'calendar' | 'reports' | 'settings';