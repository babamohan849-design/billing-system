
import React, { useState, useEffect } from 'react';
import { AppData, Tab, Bill, Service, Expense, Company, Appointment } from './types';
import { DEFAULT_SERVICES } from './constants';
import { uid, initials, fmt, today, calculateSimilarity, findBestServiceMatch } from './utils';
import { 
  subscribeToData, 
  dbSaveService, 
  dbDeleteService, 
  dbSaveExpense, 
  dbDeleteExpense, 
  dbSaveBill, 
  dbSaveCompany,
  dbSaveAppointment,
  dbDeleteAppointment
} from './firebase';
import { LayoutDashboard, Receipt, Wrench, Wallet, FileBarChart, Settings, Mic, Trash2, Plus, Printer, X, RefreshCcw, Mail, Eye, Save, Cloud, CloudOff, Loader2, AlertTriangle, Car, FileText, CheckCircle, Clock, Calendar, Phone, ChevronRight, Search, ArrowRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

// --- Subcomponents ---

const Sidebar = ({ activeTab, setTab, companyName, logo }: { activeTab: Tab, setTab: (t: Tab) => void, companyName: string, logo: string | null }) => {
  const menu = [
    { id: 'dashboard', label: 'டாஷ்போர்ட்', icon: LayoutDashboard },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'billing', label: 'பில்லிங் / Quotes', icon: Receipt },
    { id: 'services', label: 'சேவைகள்', icon: Wrench },
    { id: 'expenses', label: 'செலவுகள்', icon: Wallet },
    { id: 'reports', label: 'அறிக்கைகள்', icon: FileBarChart },
    { id: 'settings', label: 'அமைப்புகள்', icon: Settings },
  ];

  return (
    <aside className="w-72 bg-slate-900 text-slate-300 flex-shrink-0 hidden md:flex flex-col h-screen sticky top-0 print:hidden shadow-2xl transition-all">
      <div className="p-6 border-b border-slate-800 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center font-bold overflow-hidden shrink-0 shadow-lg shadow-blue-900/50">
          {logo ? <img src={logo} alt="Logo" className="w-full h-full object-cover" /> : <span className="text-lg">{initials(companyName)}</span>}
        </div>
        <div className="overflow-hidden">
          <div className="font-bold text-white text-lg truncate tracking-tight">{companyName || 'Garage Pro'}</div>
          <div className="text-xs text-slate-400 font-medium">Billing System</div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
        <div className="text-xs font-bold text-slate-500 uppercase px-4 py-2 tracking-wider">Menu</div>
        {menu.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id as Tab)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium transition-all duration-200 group ${
                isActive
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-900/30 translate-x-1'
                  : 'hover:bg-slate-800 hover:text-white hover:translate-x-1'
              }`}
            >
              <Icon size={20} className={`${isActive ? 'text-white' : 'text-slate-500 group-hover:text-white'} transition-colors`} />
              <span>{item.label}</span>
              {isActive && <ChevronRight size={16} className="ml-auto opacity-70" />}
            </button>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
           <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
             <Cloud size={14} className="text-emerald-500" /> 
             <span>System Online</span>
           </div>
           <div className="text-[10px] text-slate-500">v2.5.0 • Sync Active</div>
        </div>
      </div>
    </aside>
  );
};

const InvoiceTemplate = ({ bill, company }: { bill: Bill, company: Company }) => {
  const isQuote = bill.type === 'quote';
  
  return (
    <div className="bg-white p-8 max-w-3xl mx-auto text-slate-900 font-sans shadow-xl rounded-none print:shadow-none print:rounded-none" id="invoice-template">
      {/* Decorative Header Bar */}
      <div className="h-2 w-full bg-gradient-to-r from-blue-600 to-indigo-600 mb-8 print:block"></div>

      {/* Status Ribbon */}
      {!isQuote && (
        <div className={`absolute top-8 right-8 px-4 py-1 text-xs font-bold text-white uppercase tracking-widest rounded shadow-sm ${bill.status === 'paid' ? 'bg-emerald-500' : 'bg-amber-500'}`}>
          {bill.status === 'paid' ? 'PAYÉ' : 'EN ATTENTE'}
        </div>
      )}

      <div className="flex justify-between items-start border-b border-slate-100 pb-8 mb-8">
        <div className="space-y-1.5">
          {company.logo ? (
            <img src={company.logo} alt="Logo" className="h-24 w-auto object-contain mb-4" />
          ) : (
            <div className="text-3xl font-bold text-blue-700 mb-4 tracking-tight">{company.name}</div>
          )}
          <div className="font-bold text-xl text-slate-800">{company.name}</div>
          <div className="whitespace-pre-wrap text-sm text-slate-600 max-w-[250px] leading-relaxed">{company.address}</div>
          <div className="text-sm text-slate-600 flex items-center gap-2"><Phone size={14}/> {company.phone}</div>
          <div className="text-sm text-slate-600 flex items-center gap-2"><Mail size={14}/> {company.email}</div>
        </div>
        <div className="text-right">
          <h1 className="text-4xl font-extrabold text-slate-900 mb-2 uppercase tracking-tight">{isQuote ? 'DEVIS' : 'FACTURE'}</h1>
          <div className="font-mono font-bold text-slate-600 text-lg">N° {bill.billNumber}</div>
          <div className="text-slate-500 mt-1 font-medium">Date: {new Date(bill.date).toLocaleDateString('fr-FR')}</div>
          
          {/* Vehicle Info Box */}
          {(bill.vehicleNo || bill.vehicleModel) && (
            <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200 text-left min-w-[220px] shadow-sm">
              <div className="text-xs font-bold text-slate-400 uppercase mb-2 tracking-wider flex items-center gap-1">
                <Car size={12} /> Véhicule
              </div>
              {bill.vehicleModel && <div className="font-bold text-slate-800 text-sm mb-1">{bill.vehicleModel}</div>}
              {bill.vehicleNo && (
                <div className="font-mono font-bold text-slate-700 bg-white px-2 py-1 border border-slate-200 rounded inline-block text-sm">
                  {bill.vehicleNo}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="mb-10">
        <div className="text-xs font-bold text-slate-400 uppercase mb-2 tracking-wider">Facturer à:</div>
        <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100">
           {bill.customer ? <div className="font-bold text-xl text-slate-800">{bill.customer}</div> : <div className="text-slate-400 italic">Client divers</div>}
           {bill.customerEmail && <div className="text-sm text-slate-500 mt-1">{bill.customerEmail}</div>}
        </div>
      </div>

      <table className="w-full text-sm border-collapse mb-8">
        <thead>
          <tr className="bg-slate-800 text-white rounded-t-lg overflow-hidden">
            <th className="p-4 text-left font-semibold first:rounded-tl-lg">Description</th>
            <th className="p-4 text-right font-semibold">Prix Unitaire</th>
            <th className="p-4 text-right font-semibold">Qté</th>
            <th className="p-4 text-right font-semibold last:rounded-tr-lg">Total</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {bill.items.map((item, i) => (
            <tr key={i} className="even:bg-slate-50/50">
              <td className="p-4">
                <div className="font-bold text-slate-800 text-sm">{item.nameFr}</div>
                <div className="text-xs text-slate-500 mt-0.5 font-noto">{item.nameTa}</div>
              </td>
              <td className="p-4 text-right font-mono text-slate-600">{fmt(item.price)}</td>
              <td className="p-4 text-right font-mono text-slate-600">{item.qty}</td>
              <td className="p-4 text-right font-bold font-mono text-slate-800">{fmt(item.total)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end mb-10">
        <div className="w-72 space-y-3 text-sm bg-slate-50 p-6 rounded-xl border border-slate-100">
          <div className="flex justify-between items-center text-slate-600">
            <span className="font-medium">Sous-total:</span>
            <span className="font-mono">{fmt(bill.subTotal)}</span>
          </div>
          {bill.taxRate > 0 && (
            <div className="flex justify-between items-center text-slate-600 pb-3 border-b border-slate-200">
              <span className="font-medium">Taxe ({bill.taxRate}%):</span>
              <span className="font-mono">{fmt(bill.taxAmount)}</span>
            </div>
          )}
          <div className="flex justify-between items-center text-xl font-extrabold text-blue-900 pt-2">
            <span>Total:</span>
            <span>{fmt(bill.total)}</span>
          </div>
        </div>
      </div>

      {bill.notes && (
        <div className="mb-8 p-5 bg-yellow-50/50 rounded-xl border border-yellow-100 text-sm">
          <div className="font-bold mb-2 text-yellow-800 uppercase text-xs tracking-wider">Notes:</div>
          <div className="text-slate-700 whitespace-pre-wrap font-medium">{bill.notes}</div>
        </div>
      )}

      <div className="pt-8 border-t border-slate-200 text-center text-xs text-slate-400">
        <p className="mb-1 font-medium text-slate-500">Merci pour votre confiance.</p>
        <p>En cas de questions, veuillez nous contacter au {company.phone}.</p>
      </div>
    </div>
  );
};

// --- Feature Components ---

const StatCard = ({ title, value, subtext, color, icon: Icon }: { title: string, value: string, subtext?: string, color: 'green' | 'orange' | 'red' | 'blue', icon: any }) => {
  const gradients = {
    green: 'from-emerald-500 to-teal-600 shadow-emerald-200',
    orange: 'from-amber-500 to-orange-600 shadow-orange-200',
    red: 'from-rose-500 to-pink-600 shadow-rose-200',
    blue: 'from-blue-500 to-indigo-600 shadow-blue-200'
  };
  
  return (
    <div className={`bg-gradient-to-br ${gradients[color]} p-6 rounded-2xl shadow-lg text-white relative overflow-hidden group transition-all hover:scale-[1.02]`}>
      <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-white opacity-10 rounded-full blur-xl group-hover:scale-150 transition-transform duration-500"></div>
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="text-xs font-bold uppercase tracking-wider opacity-90">{title}</div>
          <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
            <Icon size={18} className="text-white" />
          </div>
        </div>
        <div className="text-3xl font-extrabold mb-1 tracking-tight">{value}</div>
        {subtext && <div className="text-xs font-medium opacity-80">{subtext}</div>}
      </div>
    </div>
  );
};

const Dashboard = ({ data }: { data: AppData }) => {
  const invoices = data.bills.filter(b => b.type !== 'quote');
  const totalIncome = invoices.reduce((sum, b) => sum + b.total, 0);
  const pendingIncome = invoices.filter(b => b.status === 'pending').reduce((sum, b) => sum + b.total, 0);
  const totalExpense = data.expenses.reduce((sum, e) => sum + e.amount, 0);
  const profit = totalIncome - totalExpense;

  const todayDate = today();
  const todaysAppointments = data.appointments.filter(a => a.date === todayDate && a.status === 'scheduled');

  return (
    <div className="space-y-8 animate-fade-in pb-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight">டாஷ்போர்ட் <span className="text-lg font-normal text-slate-400 ml-2">Overview</span></h1>
        <div className="text-sm text-slate-500 font-medium bg-white px-4 py-2 rounded-full shadow-sm border border-slate-200">
          {new Date().toLocaleDateString('ta-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatCard 
          title="மொத்த வருமானம்" 
          value={fmt(totalIncome)} 
          subtext={`${invoices.length} பில்கள்`} 
          color="green" 
          icon={Receipt} 
        />
        <StatCard 
          title="நிலுவையில் உள்ளது" 
          value={fmt(pendingIncome)} 
          subtext="வசூலிக்கப்பட வேண்டும்" 
          color="orange" 
          icon={Clock} 
        />
        <StatCard 
          title="மொத்த செலவுகள்" 
          value={fmt(totalExpense)} 
          color="red" 
          icon={Wallet} 
        />
        <StatCard 
          title="லாபம்" 
          value={fmt(profit)} 
          color="blue" 
          icon={FileBarChart} 
        />
      </div>

      {/* Appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         {/* Today's Appointments */}
         <div className="lg:col-span-1 bg-white rounded-2xl border border-slate-100 shadow-xl shadow-slate-200/60 p-6 h-full">
           <div className="flex items-center justify-between mb-6">
             <h3 className="font-bold text-slate-800 flex items-center gap-2 text-lg">
               <Calendar size={20} className="text-blue-600" />
               இன்றைய சந்திப்புகள்
             </h3>
             <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded-full">{todaysAppointments.length}</span>
           </div>
           
           <div className="space-y-3 overflow-y-auto max-h-[300px] pr-2 custom-scrollbar">
             {todaysAppointments.length > 0 ? (
               todaysAppointments.map(appt => (
                 <div key={appt.id} className="flex items-center gap-4 p-4 bg-slate-50 hover:bg-blue-50 rounded-xl border border-slate-100 transition-colors group">
                   <div className="bg-white text-blue-600 px-3 py-2 rounded-lg font-bold text-sm border border-blue-100 shadow-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
                     {appt.time}
                   </div>
                   <div className="min-w-0">
                     <div className="font-bold text-slate-800 truncate">{appt.customer}</div>
                     <div className="text-xs text-slate-500 truncate flex items-center gap-1">
                       <Car size={10}/> {appt.vehicleNo}
                     </div>
                   </div>
                 </div>
               ))
             ) : (
               <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                 <div className="text-slate-400 text-sm font-medium">இன்று சந்திப்புகள் இல்லை</div>
               </div>
             )}
           </div>
         </div>

         {/* Recent Bills */}
         <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-xl shadow-slate-200/60 overflow-hidden flex flex-col">
           <div className="px-6 py-5 border-b border-slate-50 flex justify-between items-center bg-white sticky top-0 z-10">
             <h3 className="font-bold text-slate-800 text-lg">சமீபத்திய பில்கள்</h3>
             <button className="text-blue-600 text-sm font-medium hover:text-blue-800 flex items-center gap-1">View All <ArrowRight size={14}/></button>
           </div>
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-slate-50/80 text-slate-500 text-xs uppercase tracking-wider">
                 <tr>
                   <th className="px-6 py-4 font-semibold">பில்</th>
                   <th className="px-6 py-4 font-semibold">வண்டி</th>
                   <th className="px-6 py-4 font-semibold text-right">மொத்தம்</th>
                   <th className="px-6 py-4 font-semibold text-center">நிலை</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                 {data.bills.slice(0, 5).map(bill => (
                   <tr key={bill.id} className="hover:bg-blue-50/30 transition-colors">
                     <td className="px-6 py-4">
                       <div className="font-bold text-slate-800">{bill.billNumber}</div>
                       <div className="text-xs text-slate-500">{bill.type === 'quote' ? 'Quote' : 'Invoice'}</div>
                     </td>
                     <td className="px-6 py-4 text-slate-600">
                       {bill.vehicleNo ? (
                         <div className="font-mono text-xs bg-slate-100 border border-slate-200 px-2 py-0.5 rounded inline-block text-slate-700 font-medium">{bill.vehicleNo}</div>
                       ) : (
                         <span className="text-slate-400">-</span>
                       )}
                     </td>
                     <td className="px-6 py-4 text-right font-bold text-slate-700">{fmt(bill.total)}</td>
                     <td className="px-6 py-4 text-center">
                        <span className={`text-[10px] uppercase tracking-wider font-bold px-3 py-1 rounded-full ${
                          bill.type === 'quote' ? 'bg-slate-100 text-slate-600 border border-slate-200' :
                          bill.status === 'paid' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' : 'bg-amber-100 text-amber-700 border border-amber-200'
                        }`}>
                          {bill.type === 'quote' ? 'Devis' : bill.status === 'paid' ? 'Paid' : 'Pending'}
                        </span>
                     </td>
                   </tr>
                 ))}
                 {data.bills.length === 0 && <tr><td colSpan={4} className="px-6 py-12 text-center text-slate-400">தரவு இல்லை</td></tr>}
               </tbody>
             </table>
           </div>
         </div>
      </div>
    </div>
  );
};

const Billing = ({ 
  data, 
  onGenerate
}: { 
  data: AppData, 
  onGenerate: (b: Bill) => void
}) => {
  const [currentBill, setCurrentBill] = useState<Partial<Bill> & { items: (Service & { qty: number, total: number })[] }>({
    items: [],
    date: today(),
    taxRate: 0,
    customer: '',
    customerEmail: '',
    vehicleNo: '',
    vehicleModel: '',
    notes: '',
    type: 'invoice',
    status: 'paid'
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [voiceStatus, setVoiceStatus] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  useEffect(() => {
    const plate = currentBill.vehicleNo?.trim().toUpperCase();
    if (plate && plate.length > 2) {
      const previousBill = data.bills.find(b => b.vehicleNo?.replace(/\s/g, '').toUpperCase() === plate.replace(/\s/g, ''));
      if (previousBill) {
        setCurrentBill(prev => ({
          ...prev,
          customer: prev.customer || previousBill.customer,
          customerEmail: prev.customerEmail || previousBill.customerEmail,
          vehicleModel: prev.vehicleModel || previousBill.vehicleModel
        }));
      }
    }
  }, [currentBill.vehicleNo, data.bills]);

  const calculateTotals = () => {
    const subTotal = currentBill.items.reduce((sum, i) => sum + i.total, 0);
    const taxAmount = subTotal * ((currentBill.taxRate || 0) / 100);
    const total = subTotal + taxAmount;
    return { subTotal, taxAmount, total };
  };

  const { subTotal, taxAmount, total } = calculateTotals();

  const addToBill = (service: Service) => {
    setCurrentBill(prev => {
      const existing = prev.items.find(i => i.id === service.id);
      if (existing) {
        return {
          ...prev,
          items: prev.items.map(i => i.id === service.id ? { ...i, qty: i.qty + 1, total: (i.qty + 1) * i.price } : i)
        };
      }
      return {
        ...prev,
        items: [...prev.items, { ...service, qty: 1, total: service.price }]
      };
    });
  };

  const handleVoiceSearch = () => {
    const Speech = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!Speech) {
      setVoiceStatus('Browser not supported');
      return;
    }
    const recognition = new Speech();
    recognition.lang = 'ta-IN';
    recognition.interimResults = false;
    recognition.maxAlternatives = 5;

    recognition.onstart = () => { setIsRecording(true); setVoiceStatus('கேட்கிறது...'); };
    recognition.onend = () => { setIsRecording(false); };
    recognition.onerror = (e: any) => { setIsRecording(false); setVoiceStatus('Error: ' + e.error); };

    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setSearchTerm(transcript);
      setVoiceStatus(`கேட்டது: "${transcript}"`);

      const allTranscripts = [];
      for (let i = 0; i < e.results.length; i++) {
        for (let j = 0; j < e.results[i].length; j++) {
          allTranscripts.push(e.results[i][j].transcript);
        }
      }

      let bestMatch = null;
      let bestScore = 0;

      for (const t of allTranscripts) {
        const res = findBestServiceMatch(t, data.services);
        if (res && res.score > bestScore) {
          bestScore = res.score;
          bestMatch = res.match;
        }
      }

      if (bestMatch) {
        addToBill(bestMatch);
        setVoiceStatus(`சேர்க்கப்பட்டது: ${bestMatch.nameTa}`);
      } else {
        setVoiceStatus(`பொருத்தமில்லை: ${transcript}`);
      }
    };

    recognition.start();
  };

  const filteredServices = data.services.filter(s =>
    !searchTerm ||
    calculateSimilarity(searchTerm, s.nameTa) > 30 ||
    s.nameTa.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.nameFr.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => {
    if (!searchTerm) return a.nameTa.localeCompare(b.nameTa);
    const scoreA = calculateSimilarity(searchTerm, a.nameTa);
    const scoreB = calculateSimilarity(searchTerm, b.nameTa);
    return scoreB - scoreA;
  });

  const generateBill = () => {
    if (currentBill.items.length === 0) return alert('சேவைகளைச் சேர்க்கவும்');
    const prefix = currentBill.type === 'quote' ? 'EST-' : 'BILL-';
    const newBill: Bill = {
      id: uid('bill'),
      billNumber: `${prefix}${String(data.bills.length + 1).padStart(4, '0')}`,
      date: currentBill.date!,
      customer: currentBill.customer || '',
      customerEmail: currentBill.customerEmail || '',
      vehicleNo: currentBill.vehicleNo?.toUpperCase() || '',
      vehicleModel: currentBill.vehicleModel || '',
      type: currentBill.type || 'invoice',
      status: currentBill.status || 'pending',
      items: currentBill.items,
      notes: currentBill.notes || '',
      taxRate: currentBill.taxRate || 0,
      subTotal,
      taxAmount,
      total
    };
    dbSaveBill(newBill);
    onGenerate(newBill);
    setCurrentBill({ 
      items: [], date: today(), taxRate: 0, 
      customer: '', customerEmail: '', 
      vehicleNo: '', vehicleModel: '', 
      notes: '', type: 'invoice', status: 'paid' 
    });
    setSearchTerm('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-100px)]">
      {/* Left: Search */}
      <div className="lg:col-span-5 flex flex-col h-full bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 overflow-hidden">
        <div className="p-5 border-b border-slate-100 bg-white z-10">
          <h2 className="font-bold text-slate-800 mb-3 flex items-center gap-2">
            <Search size={18} className="text-blue-500"/> 
            சேவை தேர்வு
          </h2>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white outline-none transition-all text-sm"
                placeholder="தமிழில் தேடவும்..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
              <Search size={16} className="absolute left-3 top-3 text-slate-400" />
            </div>
            <button
              onClick={handleVoiceSearch}
              className={`p-2.5 rounded-xl transition-all shadow-sm ${isRecording ? 'bg-rose-500 animate-pulse text-white shadow-rose-500/50' : 'bg-blue-50 text-blue-600 hover:bg-blue-100'}`}
            >
              <Mic size={20} />
            </button>
          </div>
          <div className={`h-5 mt-2 text-xs truncate font-medium transition-colors ${isRecording ? 'text-rose-500' : 'text-slate-400'}`}>
            {voiceStatus || 'Ready for voice search'}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar bg-slate-50/50">
          {filteredServices.map(s => (
            <div key={s.id} className="flex items-center justify-between p-3.5 bg-white hover:bg-blue-50 rounded-xl border border-slate-200 hover:border-blue-200 shadow-sm transition-all group cursor-pointer" onClick={() => addToBill(s)}>
              <div>
                <div className="font-bold text-slate-800 text-sm">{s.nameTa}</div>
                <div className="text-xs text-slate-500 group-hover:text-blue-600 transition-colors">{s.nameFr}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold text-slate-700 text-sm">{fmt(s.price)}</span>
                <button className="w-8 h-8 flex items-center justify-center bg-blue-50 text-blue-600 rounded-full group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                  <Plus size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right: Bill Details */}
      <div className="lg:col-span-7 flex flex-col h-full bg-white rounded-2xl border border-slate-200 shadow-xl shadow-slate-200/50 overflow-hidden">
        <div className="p-5 border-b border-slate-100 bg-slate-50/80 backdrop-blur-sm">
          {/* Type Selection */}
          <div className="flex gap-1 bg-slate-200/50 p-1 rounded-lg w-fit mb-5">
            {['invoice', 'quote'].map(t => (
               <button
                key={t}
                onClick={() => setCurrentBill({...currentBill, type: t as any})}
                className={`px-4 py-1.5 rounded-md text-sm font-bold transition-all ${currentBill.type === t ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
               >
                 {t === 'invoice' ? 'Invoice (பில்)' : 'Quote (மதிப்பீடு)'}
               </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-5">
            {/* Vehicle Row */}
            <div className="col-span-1 space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1"><Car size={12} /> வண்டி எண்</label>
              <input
                className="w-full px-3 py-2 border border-slate-300 bg-white rounded-lg text-sm font-mono uppercase focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                value={currentBill.vehicleNo}
                onChange={e => setCurrentBill({ ...currentBill, vehicleNo: e.target.value })}
                placeholder="AB-123-CD"
              />
            </div>
            <div className="col-span-1 space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">வண்டி மாடல்</label>
              <input
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                value={currentBill.vehicleModel}
                onChange={e => setCurrentBill({ ...currentBill, vehicleModel: e.target.value })}
                placeholder="e.g. Peugeot 208"
              />
            </div>

            {/* Customer Row */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">வாடிக்கையாளர் பெயர்</label>
              <input
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                value={currentBill.customer}
                onChange={e => setCurrentBill({ ...currentBill, customer: e.target.value })}
                placeholder="பெயர்"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">வாடிக்கையாளர் Email</label>
              <input
                type="email"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                value={currentBill.customerEmail}
                onChange={e => setCurrentBill({ ...currentBill, customerEmail: e.target.value })}
                placeholder="email@example.com"
              />
            </div>

            {/* Meta Row */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">தேதி</label>
              <input
                type="date"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                value={currentBill.date}
                onChange={e => setCurrentBill({ ...currentBill, date: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">வரி (%)</label>
                <input
                  type="number"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm"
                  value={currentBill.taxRate}
                  onChange={e => setCurrentBill({ ...currentBill, taxRate: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wide">நிலை</label>
                <select 
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none shadow-sm bg-white"
                  value={currentBill.status}
                  onChange={e => setCurrentBill({ ...currentBill, status: e.target.value as any })}
                >
                  <option value="paid">Paid</option>
                  <option value="pending">Pending</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-0 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-500 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="px-5 py-3 text-left font-semibold">விவரம்</th>
                <th className="px-5 py-3 text-right font-semibold">விலை</th>
                <th className="px-5 py-3 text-right w-24 font-semibold">அளவு</th>
                <th className="px-5 py-3 text-right font-semibold">மொத்தம்</th>
                <th className="px-5 py-3 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {currentBill.items.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-5 py-3.5">
                    <div className="font-bold text-slate-800">{item.nameTa}</div>
                    <div className="text-xs text-slate-400">{item.nameFr}</div>
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono text-slate-600">{fmt(item.price)}</td>
                  <td className="px-5 py-3.5 text-right">
                    <input
                      type="number"
                      className="w-16 p-1.5 text-center border border-slate-200 rounded-md text-slate-700 focus:border-blue-500 outline-none"
                      value={item.qty}
                      min="1"
                      onChange={(e) => {
                        const qty = parseInt(e.target.value) || 1;
                        const newItems = [...currentBill.items];
                        newItems[idx] = { ...item, qty, total: item.price * qty };
                        setCurrentBill({ ...currentBill, items: newItems });
                      }}
                    />
                  </td>
                  <td className="px-5 py-3.5 text-right font-bold text-slate-800">{fmt(item.total)}</td>
                  <td className="px-5 py-3.5 text-right">
                    <button
                      onClick={() => {
                        const newItems = currentBill.items.filter((_, i) => i !== idx);
                        setCurrentBill({ ...currentBill, items: newItems });
                      }}
                      className="w-8 h-8 flex items-center justify-center text-rose-400 hover:bg-rose-50 hover:text-rose-600 rounded-full transition-colors"
                    >
                      <X size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {currentBill.items.length === 0 && (
                <tr><td colSpan={5} className="text-center py-16 text-slate-400 flex flex-col items-center gap-2">
                  <div className="bg-slate-100 p-4 rounded-full"><Plus size={24} className="text-slate-300"/></div>
                  <span>உருப்படிகள் இல்லை. இடதுபுறம் இருந்து சேர்க்கவும்.</span>
                </td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-5 border-t border-slate-100 bg-slate-50 space-y-4 shadow-[0_-4px_15px_rgba(0,0,0,0.05)] z-20">
          <textarea
            className="w-full p-3 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none shadow-sm"
            placeholder="குறிப்புகள் (விரும்பினால்)..."
            rows={2}
            value={currentBill.notes}
            onChange={e => setCurrentBill({ ...currentBill, notes: e.target.value })}
          />
          <div className="flex items-end justify-between">
            <div className="text-sm space-y-2 bg-white p-3 rounded-lg border border-slate-200 shadow-sm min-w-[200px]">
              <div className="flex justify-between text-slate-500"><span>கூட்டுத்தொகை:</span> <span className="font-medium">{fmt(subTotal)}</span></div>
              <div className="flex justify-between text-slate-500"><span>வரி ({currentBill.taxRate}%):</span> <span className="font-medium">{fmt(taxAmount)}</span></div>
              <div className="border-t border-slate-100 pt-2 mt-1 flex justify-between font-bold text-slate-800 text-lg"><span>மொத்தம்:</span> <span className="text-blue-700">{fmt(total)}</span></div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setCurrentBill({ 
                  items: [], date: today(), taxRate: 0, 
                  customer: '', customerEmail: '', 
                  vehicleNo: '', vehicleModel: '',
                  notes: '', type: 'invoice', status: 'paid'
                })}
                className="px-5 py-2.5 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 text-slate-600 font-medium transition-colors"
              >
                மீட்டமை
              </button>
              <button
                onClick={generateBill}
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:shadow-lg hover:shadow-blue-500/30 flex items-center gap-2 font-bold transition-all active:scale-95"
              >
                <Eye size={20} />
                {currentBill.type === 'quote' ? 'Preview Quote' : 'Preview Bill'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const AppointmentManager = ({ data }: { data: AppData }) => {
  const [form, setForm] = useState<Partial<Appointment>>({ customer: '', phone: '', vehicleNo: '', date: today(), time: '09:00', service: '', status: 'scheduled' });
  
  const handleSave = () => {
    if(!form.customer || !form.date || !form.time) return alert("Customer, Date and Time required");
    
    const appt: Appointment = {
      id: uid('appt'),
      customer: form.customer!,
      phone: form.phone || '',
      vehicleNo: form.vehicleNo || '',
      date: form.date!,
      time: form.time!,
      service: form.service || 'General Checkup',
      status: form.status || 'scheduled',
      notes: form.notes || ''
    };

    dbSaveAppointment(appt);
    setForm({ customer: '', phone: '', vehicleNo: '', date: today(), time: '09:00', service: '', status: 'scheduled' });
  };

  const sortedAppts = [...data.appointments].sort((a,b) => {
    const dateA = new Date(`${a.date}T${a.time}`);
    const dateB = new Date(`${b.date}T${b.time}`);
    return dateA.getTime() - dateB.getTime();
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-140px)]">
       {/* Form Section */}
       <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 h-fit">
         <h3 className="font-bold text-lg mb-5 flex items-center gap-2 text-slate-800"><Calendar className="text-blue-600"/> Book Appointment</h3>
         <div className="space-y-4">
           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">Customer Name</label>
             <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.customer} onChange={e => setForm({...form, customer: e.target.value})} />
           </div>
           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">Phone</label>
             <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} />
           </div>
           <div className="grid grid-cols-2 gap-3">
             <div className="space-y-1">
               <label className="text-xs font-bold text-slate-500 uppercase">Date</label>
               <input type="date" className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.date} onChange={e => setForm({...form, date: e.target.value})} />
             </div>
             <div className="space-y-1">
               <label className="text-xs font-bold text-slate-500 uppercase">Time</label>
               <input type="time" className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.time} onChange={e => setForm({...form, time: e.target.value})} />
             </div>
           </div>
           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">Vehicle / Service</label>
             <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" placeholder="e.g. TN-01 Oil Change" value={form.service} onChange={e => setForm({...form, service: e.target.value})} />
           </div>
           <button onClick={handleSave} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-xl hover:shadow-lg hover:shadow-blue-500/30 font-bold transition-all active:scale-95 mt-2">Book Now</button>
         </div>
       </div>

       {/* List Section */}
       <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 overflow-hidden flex flex-col">
         <div className="p-5 border-b border-slate-100 font-bold text-slate-800 text-lg bg-white z-10">Upcoming Appointments</div>
         <div className="overflow-y-auto flex-1 p-5 space-y-4 custom-scrollbar bg-slate-50/50">
           {sortedAppts.map(appt => (
             <div key={appt.id} className="flex items-center gap-5 p-5 bg-white rounded-xl border border-slate-200 hover:border-blue-300 shadow-sm hover:shadow-md transition-all group">
               <div className="flex flex-col items-center justify-center min-w-[70px] bg-blue-50 rounded-lg p-2 border border-blue-100">
                 <div className="text-xs font-bold text-blue-400 uppercase">{new Date(appt.date).toLocaleDateString('en-US', { month: 'short' })}</div>
                 <div className="text-2xl font-extrabold text-blue-700">{new Date(appt.date).getDate()}</div>
                 <div className="text-xs text-blue-600 font-bold mt-1">{appt.time}</div>
               </div>
               <div className="flex-1">
                 <div className="flex justify-between items-start">
                   <div>
                     <h4 className="font-bold text-lg text-slate-800">{appt.customer}</h4>
                     <div className="text-sm text-slate-500 mt-1 flex items-center gap-2">
                       <Phone size={14} className="text-slate-400"/> {appt.phone || 'No phone'}
                     </div>
                   </div>
                   <button onClick={() => { if(confirm('Cancel appointment?')) dbDeleteAppointment(appt.id)}} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:bg-rose-50 hover:text-rose-500 rounded-full transition-colors">
                     <X size={18} />
                   </button>
                 </div>
                 <div className="flex items-center gap-2 mt-3">
                   <span className="text-xs font-bold px-2 py-1 bg-slate-100 text-slate-600 rounded border border-slate-200">{appt.vehicleNo || 'No Plate'}</span>
                   <span className="text-sm text-slate-600 font-medium">{appt.service}</span>
                 </div>
               </div>
             </div>
           ))}
           {sortedAppts.length === 0 && <div className="text-center py-12 text-slate-400 flex flex-col items-center"><Calendar size={32} className="text-slate-300 mb-2"/> No upcoming appointments</div>}
         </div>
       </div>
    </div>
  );
};

const ServicesManager = ({ data }: { data: AppData }) => {
  const [editing, setEditing] = useState<Service | null>(null);
  const [form, setForm] = useState({ nameTa: '', nameFr: '', price: '' });

  const saveService = () => {
    if (!form.nameTa || !form.nameFr || !form.price) return alert('எல்லா விவரங்களையும் உள்ளிடவும்');
    const price = parseFloat(form.price);

    if (editing) {
      dbSaveService({ ...editing, nameTa: form.nameTa, nameFr: form.nameFr, price });
      setEditing(null);
    } else {
      dbSaveService({ id: uid('svc'), nameTa: form.nameTa, nameFr: form.nameFr, price });
    }
    setForm({ nameTa: '', nameFr: '', price: '' });
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50">
        <h3 className="font-bold text-lg mb-5 flex items-center gap-2 text-slate-800">
          <Wrench className="text-blue-600"/> 
          {editing ? 'சேவையை திருத்துதல்' : 'புதிய சேவை சேர்க்க'}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">பெயர் (தமிழ்)</label>
            <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.nameTa} onChange={e => setForm({ ...form, nameTa: e.target.value })} />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Nom (Français)</label>
            <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" value={form.nameFr} onChange={e => setForm({ ...form, nameFr: e.target.value })} />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Price (€)</label>
            <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none" type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
          </div>
          <div className="flex gap-2">
            <button onClick={saveService} className="flex-1 bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700 font-bold shadow-md hover:shadow-lg transition-all">
              {editing ? 'Update' : 'Add Service'}
            </button>
            {editing && <button onClick={() => { setEditing(null); setForm({ nameTa: '', nameFr: '', price: '' }); }} className="px-4 border border-slate-300 rounded-xl hover:bg-slate-50 font-medium">Cancel</button>}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 overflow-hidden">
        <div className="flex justify-between items-center p-5 border-b border-slate-100 bg-white">
          <h3 className="font-bold text-lg text-slate-800">சேவை பட்டியல்</h3>
          <div className="text-xs text-emerald-600 font-medium flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded border border-emerald-100">
            <CheckCircle size={12} /> Live Sync
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 uppercase text-xs font-semibold">
              <tr>
                <th className="px-6 py-4">தமிழ்</th>
                <th className="px-6 py-4">Français</th>
                <th className="px-6 py-4 text-right">விலை</th>
                <th className="px-6 py-4 text-right">செயல்கள்</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {data.services.map(s => (
                <tr key={s.id} className="hover:bg-blue-50/50 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-700">{s.nameTa}</td>
                  <td className="px-6 py-4 text-slate-600">{s.nameFr}</td>
                  <td className="px-6 py-4 text-right font-mono font-medium">{fmt(s.price)}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-3">
                      <button
                        onClick={() => { setEditing(s); setForm({ nameTa: s.nameTa, nameFr: s.nameFr, price: String(s.price) }); }}
                        className="text-blue-600 hover:text-blue-800 font-medium"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          if(window.confirm('Are you sure you want to delete this service?')) {
                            dbDeleteService(s.id);
                          }
                        }}
                        className="text-rose-600 hover:text-rose-800 font-medium"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const ExpensesManager = ({ data }: { data: AppData }) => {
  const [form, setForm] = useState({ titleTa: '', typeTa: '', amount: '', date: today(), notes: '' });

  const addExpense = () => {
    if (!form.titleTa || !form.amount) return alert('விவரங்கள் தேவை');
    const newExp: Expense = {
      id: uid('exp'),
      titleTa: form.titleTa,
      typeTa: form.typeTa || 'General',
      amount: parseFloat(form.amount),
      date: form.date,
      notes: form.notes
    };
    dbSaveExpense(newExp);
    setForm({ titleTa: '', typeTa: '', amount: '', date: today(), notes: '' });
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50">
        <h3 className="font-bold text-lg mb-5 flex items-center gap-2 text-slate-800">
          <Wallet className="text-rose-600"/> புதிய செலவு சேர்க்க
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
          <div className="md:col-span-2 space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">விவரம் (தமிழ்)</label>
            <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none" value={form.titleTa} onChange={e => setForm({ ...form, titleTa: e.target.value })} />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">வகை</label>
            <input className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none" value={form.typeTa} onChange={e => setForm({ ...form, typeTa: e.target.value })} />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">தொகை (€)</label>
            <input type="number" className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} />
          </div>
          <button onClick={addExpense} className="bg-rose-600 text-white p-3 rounded-xl hover:bg-rose-700 font-bold shadow-md hover:shadow-lg transition-all">சேர்</button>
        </div>
      </div>
      
      <div className="bg-white rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 overflow-hidden">
        <div className="p-5 border-b border-slate-100 bg-white font-bold text-lg text-slate-800">செலவு பட்டியல்</div>
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-500 uppercase text-xs font-semibold">
            <tr>
              <th className="px-6 py-4">தேதி</th>
              <th className="px-6 py-4">விவரம்</th>
              <th className="px-6 py-4">வகை</th>
              <th className="px-6 py-4 text-right">தொகை</th>
              <th className="px-6 py-4 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {data.expenses.map(e => (
              <tr key={e.id} className="hover:bg-rose-50/30 transition-colors">
                <td className="px-6 py-4 text-slate-500">{new Date(e.date).toLocaleDateString('fr-FR')}</td>
                <td className="px-6 py-4 font-bold text-slate-700">{e.titleTa}</td>
                <td className="px-6 py-4 text-slate-500">{e.typeTa}</td>
                <td className="px-6 py-4 text-right font-mono font-bold text-rose-600">-{fmt(e.amount)}</td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => {
                      if(window.confirm('Delete this expense?')) {
                        dbDeleteExpense(e.id);
                      }
                    }} 
                    className="w-8 h-8 inline-flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-full transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const Reports = ({ data }: { data: AppData }) => {
  const [dateRange, setDateRange] = useState({ start: today(), end: today() });
  const [filterType, setFilterType] = useState('today');

  useEffect(() => {
    const now = new Date();
    if (filterType === 'today') {
      setDateRange({ start: today(), end: today() });
    } else if (filterType === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
      setDateRange({ start, end: today() });
    }
  }, [filterType]);

  const filteredBills = data.bills.filter(b => b.type !== 'quote' && b.date >= dateRange.start && b.date <= dateRange.end);
  const filteredExp = data.expenses.filter(e => e.date >= dateRange.start && e.date <= dateRange.end);

  const inc = filteredBills.reduce((s, b) => s + b.total, 0);
  const exp = filteredExp.reduce((s, e) => s + e.amount, 0);

  const chartData = [
    { name: 'வருமானம்', amount: inc, fill: '#10b981' }, // Emerald 500
    { name: 'செலவு', amount: exp, fill: '#f43f5e' }, // Rose 500
    { name: 'லாபம்', amount: inc - exp, fill: '#6366f1' } // Indigo 500
  ];

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 flex flex-wrap gap-6 items-end">
        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase">வடிகட்டி</label>
          <div className="relative">
            <select className="appearance-none w-48 px-4 py-2.5 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500 outline-none font-medium text-slate-700" value={filterType} onChange={e => setFilterType(e.target.value)}>
              <option value="today">இன்று</option>
              <option value="month">இந்த மாதம்</option>
              <option value="custom">தேதி வரம்பு</option>
            </select>
            <ChevronRight className="absolute right-3 top-3 text-slate-400 rotate-90 pointer-events-none" size={16}/>
          </div>
        </div>
        {filterType === 'custom' && (
          <>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">தொடக்கம்</label>
              <input type="date" className="px-4 py-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" value={dateRange.start} onChange={e => setDateRange({ ...dateRange, start: e.target.value })} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">முடிவு</label>
              <input type="date" className="px-4 py-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" value={dateRange.end} onChange={e => setDateRange({ ...dateRange, end: e.target.value })} />
            </div>
          </>
        )}
        <button onClick={() => window.print()} className="ml-auto px-6 py-2.5 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 hover:shadow-md transition-all flex items-center gap-2 font-bold">
          <Printer size={18} /> Print Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-6 rounded-2xl border border-emerald-100 shadow-sm">
          <div className="text-sm font-bold text-emerald-800 uppercase tracking-wide mb-2">மொத்த வருமானம்</div>
          <div className="text-4xl font-extrabold text-emerald-600 tracking-tight">{fmt(inc)}</div>
        </div>
        <div className="bg-gradient-to-br from-rose-50 to-pink-50 p-6 rounded-2xl border border-rose-100 shadow-sm">
          <div className="text-sm font-bold text-rose-800 uppercase tracking-wide mb-2">மொத்த செலவுகள்</div>
          <div className="text-4xl font-extrabold text-rose-600 tracking-tight">{fmt(exp)}</div>
        </div>
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-6 rounded-2xl border border-indigo-100 shadow-sm">
          <div className="text-sm font-bold text-indigo-800 uppercase tracking-wide mb-2">நிகர லாபம்</div>
          <div className="text-4xl font-extrabold text-indigo-600 tracking-tight">{fmt(inc - exp)}</div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-lg shadow-slate-200/50 h-96">
        <h3 className="font-bold text-slate-800 mb-6">Financial Overview</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} barSize={60}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 14}} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
            <Tooltip 
              cursor={{fill: 'transparent'}}
              contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'}}
              formatter={(value) => [fmt(Number(value)), 'Amount']}
            />
            <Bar dataKey="amount" radius={[12, 12, 12, 12]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

const SettingsView = ({ data, setIsSetupOpen }: { data: AppData, setIsSetupOpen: (v: boolean) => void }) => (
  <div className="max-w-2xl mx-auto mt-10">
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xl shadow-slate-200/50 p-8 text-center">
      <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
         <Settings size={40} />
      </div>
      <h2 className="text-2xl font-bold text-slate-800 mb-2">காரேஜ் அமைப்புகள்</h2>
      <p className="text-slate-500 mb-8">Manage your garage details, logo, and contact information.</p>
      
      <div className="bg-slate-50 rounded-xl p-6 border border-slate-100 text-left mb-8 space-y-3">
        <h3 className="font-bold text-slate-400 text-xs uppercase tracking-wider mb-4">Current Profile</h3>
        <div className="flex items-center gap-4">
           {data.company.logo && <img src={data.company.logo} className="w-16 h-16 rounded-lg object-cover bg-white border border-slate-200"/>}
           <div>
             <div className="font-bold text-lg text-slate-800">{data.company.name}</div>
             <div className="text-slate-500 text-sm">{data.company.email}</div>
           </div>
        </div>
        <div className="grid grid-cols-2 gap-4 pt-4 mt-4 border-t border-slate-200">
           <div>
             <span className="text-xs text-slate-400 block">Phone</span>
             <span className="font-medium text-slate-700">{data.company.phone}</span>
           </div>
           <div>
             <span className="text-xs text-slate-400 block">Address</span>
             <span className="font-medium text-slate-700 truncate">{data.company.address}</span>
           </div>
        </div>
      </div>

      <button
        onClick={() => setIsSetupOpen(true)}
        className="bg-blue-600 text-white px-8 py-3 rounded-xl hover:bg-blue-700 font-bold shadow-lg shadow-blue-500/30 transition-all hover:scale-105"
      >
        Edit Garage Profile
      </button>
      
      <div className="mt-8 text-xs text-emerald-600 font-medium flex items-center justify-center gap-2 bg-emerald-50 py-2 px-4 rounded-full w-fit mx-auto border border-emerald-100">
        <Cloud size={14} /> Data is securely synced with Cloud Database
      </div>
    </div>
  </div>
);

const SetupModal = ({ isOpen, data, onSave, onClose }: { isOpen: boolean, data: AppData, onSave: (c: AppData['company']) => void, onClose: () => void }) => {
  const [form, setForm] = useState(data.company);
  const [preview, setPreview] = useState<string | null>(data.company.logo);

  useEffect(() => {
    if(isOpen) {
      setForm(data.company);
      setPreview(data.company.logo);
    }
  }, [isOpen, data.company]);

  if (!isOpen) return null;

  const handleLogo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreview(reader.result as string);
        setForm(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 p-4 backdrop-blur-sm print:hidden animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden scale-100 transition-transform">
        <div className="px-8 py-6 border-b border-slate-100 bg-slate-50/50">
          <h2 className="font-bold text-xl text-slate-800">Setup Garage Profile</h2>
          <p className="text-sm text-slate-500 mt-1">This information will appear on your invoices.</p>
        </div>
        <div className="p-8 space-y-5">
          <div className="grid grid-cols-2 gap-5">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-500 uppercase">காரேஜ் பெயர்</label>
              <input
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                className="w-full border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Garage Name"
              />
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-500 uppercase">தொலைபேசி</label>
              <input
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="+33..."
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-500 uppercase">முகவரி</label>
            <textarea
              value={form.address}
              onChange={e => setForm({ ...form, address: e.target.value })}
              className="w-full border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
              rows={2}
            />
          </div>
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-500 uppercase">மின்னஞ்சல்</label>
            <input
              type="email"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              className="w-full border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="flex items-center gap-5 pt-2">
            <div className="flex-1 space-y-1">
              <label className="block text-xs font-bold text-slate-500 uppercase">லோகோ</label>
              <input type="file" accept="image/png, image/jpeg" onChange={handleLogo} className="text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"/>
            </div>
            {preview && <div className="p-1 border rounded-lg"><img src={preview} alt="Preview" className="w-14 h-14 rounded object-cover" /></div>}
          </div>
        </div>
        <div className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
          {data.company.name && <button onClick={onClose} className="px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors">Cancel</button>}
          <button
            onClick={() => {
              if (form.name && form.phone) {
                onSave(form);
                onClose();
              } else {
                alert('பெயர் மற்றும் தொலைபேசி அவசியம்');
              }
            }}
            className="px-6 py-2.5 text-sm font-bold bg-blue-600 text-white rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-500/30 transition-all"
          >
            Save Profile
          </button>
        </div>
      </div>
    </div>
  );
};

// --- Main App Component ---

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [data, setData] = useState<AppData>({
      services: [],
      expenses: [],
      bills: [],
      appointments: [],
      company: { name: '', address: '', email: '', phone: '', logo: null }
  });

  const [printBill, setPrintBill] = useState<Bill | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [isSetupOpen, setIsSetupOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToData(
      (newData) => {
        setData(newData);
      }, 
      setLoading,
      (err) => setErrorMsg(err)
    );

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!loading && !data.company.name && !errorMsg) {
      setIsSetupOpen(true);
    }
  }, [loading, data.company.name, errorMsg]);

  const updateCompany = (company: AppData['company']) => dbSaveCompany(company);
  
  const handleGenerateBill = (newBill: Bill) => {
    setPrintBill(newBill);
    setShowPreview(true);
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 gap-4">
        <Loader2 className="animate-spin text-blue-600" size={56} />
        <p className="text-slate-400 font-medium text-sm tracking-wide uppercase">Loading Garage Pro...</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-900">
      <Sidebar activeTab={activeTab} setTab={setActiveTab} companyName={data.company.name} logo={data.company.logo} />

      <main className="flex-1 flex flex-col h-screen overflow-hidden relative print:hidden">
        {/* Mobile Header */}
        <header className="md:hidden h-16 bg-slate-900 text-white flex items-center justify-between px-4 shrink-0 print:hidden shadow-md z-30">
          <div className="font-bold text-lg">{activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}</div>
          <button onClick={() => setIsSetupOpen(true)} className="p-2 bg-white/10 rounded-lg"><Settings size={20} /></button>
        </header>

        {/* Error Banner */}
        {errorMsg && (
          <div className="bg-rose-50 border-b border-rose-100 text-rose-700 p-4 flex items-start gap-3">
            <AlertTriangle className="shrink-0 mt-0.5" size={20} />
            <div>
              <div className="font-bold">Connection Error</div>
              <div className="text-sm">{errorMsg}</div>
            </div>
          </div>
        )}

        {/* Mobile Nav */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-slate-200 flex justify-around items-center z-40 print:hidden overflow-x-auto shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
          {['dashboard', 'calendar', 'billing', 'services', 'expenses', 'reports'].map(t => (
            <button key={t} onClick={() => setActiveTab(t as Tab)} className={`p-3 rounded-xl transition-all ${activeTab === t ? 'text-blue-600 bg-blue-50' : 'text-slate-400'}`}>
              {t === 'dashboard' && <LayoutDashboard size={22} />}
              {t === 'calendar' && <Calendar size={22} />}
              {t === 'billing' && <Receipt size={22} />}
              {t === 'services' && <Wrench size={22} />}
              {t === 'expenses' && <Wallet size={22} />}
              {t === 'reports' && <FileBarChart size={22} />}
            </button>
          ))}
        </nav>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8 print:p-0 bg-slate-100 custom-scrollbar">
          <div className="max-w-[1400px] mx-auto print:hidden">
            {activeTab === 'dashboard' && <Dashboard data={data} />}
            {activeTab === 'calendar' && <AppointmentManager data={data} />}
            {activeTab === 'billing' && <Billing data={data} onGenerate={handleGenerateBill} />}
            {activeTab === 'services' && <ServicesManager data={data} />}
            {activeTab === 'expenses' && <ExpensesManager data={data} />}
            {activeTab === 'reports' && <Reports data={data} />}
            {activeTab === 'settings' && <SettingsView data={data} setIsSetupOpen={setIsSetupOpen} />}
          </div>
        </div>
      </main>

      {/* Preview Modal */}
      {showPreview && printBill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/90 p-4 print:hidden backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-white">
              <h2 className="font-bold text-lg flex items-center gap-2 text-slate-800">
                <Eye size={20} className="text-blue-600" />
                {printBill.type === 'quote' ? 'Quote Preview' : 'Invoice Preview'}
              </h2>
              <button onClick={() => setShowPreview(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={20} className="text-slate-500"/></button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 bg-slate-50 custom-scrollbar">
              <div className="shadow-2xl shadow-slate-300/50 rounded-none mx-auto max-w-3xl">
                <InvoiceTemplate bill={printBill} company={data.company} />
              </div>
            </div>

            <div className="p-5 border-t border-slate-200 bg-white flex flex-col md:flex-row justify-between items-center gap-4 shadow-[0_-4px_20px_rgba(0,0,0,0.05)] z-10">
              <div className="text-xs text-slate-400 font-medium flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                Ready to Print
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    if (!printBill.customerEmail) {
                      alert("Customer email is missing.");
                      return;
                    }
                    const type = printBill.type === 'quote' ? 'Quote (Devis)' : 'Invoice';
                    const subject = encodeURIComponent(`${type} ${printBill.billNumber} - ${data.company.name}`);
                    const body = encodeURIComponent(`Dear ${printBill.customer},\n\nPlease find attached the ${type.toLowerCase()} ${printBill.billNumber}.\n\nTotal Amount: ${fmt(printBill.total)}\n\nThank you,\n${data.company.name}`);
                    const cc = data.company.email ? `&cc=${data.company.email}` : '';
                    window.location.href = `mailto:${printBill.customerEmail}?subject=${subject}&body=${body}${cc}`;
                  }}
                  className="px-5 py-2.5 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 flex items-center gap-2 font-bold transition-colors"
                >
                  <Mail size={18} />
                  Email Client
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-8 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-500/30 flex items-center gap-2 font-bold transition-all active:scale-95"
                >
                  <Printer size={18} />
                  Print PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Print Component - Hidden on screen, visible on print */}
      <div className="hidden print:block absolute top-0 left-0 w-full min-h-screen bg-white z-[9999] text-black p-0">
        {printBill && <InvoiceTemplate bill={printBill} company={data.company} />}
      </div>

      <SetupModal
        isOpen={isSetupOpen}
        data={data}
        onSave={updateCompany}
        onClose={() => setIsSetupOpen(false)}
      />
    </div>
  );
}
