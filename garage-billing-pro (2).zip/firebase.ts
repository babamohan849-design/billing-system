
import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy,
  limit
} from "firebase/firestore";
import { AppData, Service, Expense, Bill, Company, Appointment } from "./types";
import { DEFAULT_SERVICES } from "./constants";

// --- CONFIGURATION ---
const firebaseConfig = {
  apiKey: "AIzaSyBvc_wTTk39eZ5qon4u5vIjnuxdcY_O9kI",
  authDomain: "studyai-t7t3e.firebaseapp.com",
  projectId: "studyai-t7t3e",
  storageBucket: "studyai-t7t3e.firebasestorage.app",
  messagingSenderId: "180680436933",
  appId: "1:180680436933:web:cf0bc940452d4cd0c214ac"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// --- COLLECTIONS ---
const SERVICES_COL = "services";
const EXPENSES_COL = "expenses";
const BILLS_COL = "bills";
const APPOINTMENTS_COL = "appointments";
const SETTINGS_COL = "settings";
const COMPANY_DOC = "companyProfile";

// --- HELPERS ---

// 1. Real-time Data Listener
export const subscribeToData = (
  onData: (data: AppData) => void,
  setLoading: (loading: boolean) => void,
  onError?: (msg: string) => void
) => {
  const data: AppData = {
    services: [],
    expenses: [],
    bills: [],
    appointments: [],
    company: { name: '', address: '', email: '', phone: '', logo: null }
  };

  let loadedCount = 0;
  const totalCollections = 5; // Services, Expenses, Bills, Company, Appointments

  const checkLoaded = () => {
    loadedCount++;
    if (loadedCount >= totalCollections) setLoading(false);
  };

  const handleSnapshotError = (error: any, context: string) => {
    console.error(`Error fetching ${context}:`, error);
    if (error.code === 'permission-denied') {
      const msg = "Database permission denied. Please update Firestore Rules to 'allow read, write: if true;' in Firebase Console.";
      console.warn(msg);
      if (onError) onError(msg);
    }
    checkLoaded();
  };

  // Listen to Services
  const unsubServices = onSnapshot(collection(db, SERVICES_COL), (snapshot) => {
    const services = snapshot.docs.map(doc => doc.data() as Service);
    data.services = services.length > 0 ? services : [...DEFAULT_SERVICES];
    onData({ ...data });
    checkLoaded();
  }, (error) => {
    data.services = [...DEFAULT_SERVICES];
    onData({ ...data });
    handleSnapshotError(error, 'Services');
  });

  // Listen to Expenses (Ordered by date)
  const expQuery = query(collection(db, EXPENSES_COL), orderBy("date", "desc"), limit(100));
  const unsubExpenses = onSnapshot(expQuery, (snapshot) => {
    data.expenses = snapshot.docs.map(doc => doc.data() as Expense);
    onData({ ...data });
    checkLoaded();
  }, (error) => handleSnapshotError(error, 'Expenses'));

  // Listen to Bills (Ordered by date)
  const billQuery = query(collection(db, BILLS_COL), orderBy("date", "desc"), limit(100));
  const unsubBills = onSnapshot(billQuery, (snapshot) => {
    data.bills = snapshot.docs.map(doc => doc.data() as Bill);
    onData({ ...data });
    checkLoaded();
  }, (error) => handleSnapshotError(error, 'Bills'));

  // Listen to Appointments
  const apptQuery = query(collection(db, APPOINTMENTS_COL), orderBy("date", "asc")); // Future first? Or filter locally.
  const unsubAppointments = onSnapshot(apptQuery, (snapshot) => {
    data.appointments = snapshot.docs.map(doc => doc.data() as Appointment);
    onData({ ...data });
    checkLoaded();
  }, (error) => handleSnapshotError(error, 'Appointments'));

  // Listen to Company Settings
  const unsubCompany = onSnapshot(doc(db, SETTINGS_COL, COMPANY_DOC), (doc) => {
    if (doc.exists()) {
      data.company = doc.data() as Company;
    }
    onData({ ...data });
    checkLoaded();
  }, (error) => handleSnapshotError(error, 'Company Settings'));

  // Return unsubscribe function to clean up listeners
  return () => {
    unsubServices();
    unsubExpenses();
    unsubBills();
    unsubAppointments();
    unsubCompany();
  };
};

// 2. CRUD Operations

export const saveItem = async (collectionName: string, item: any) => {
  try {
    await setDoc(doc(db, collectionName, item.id), item);
  } catch (e: any) {
    console.error("Error saving item:", e);
    if (e.code === 'permission-denied') {
      alert("Permission denied! Cannot save data. Check Firestore Rules.");
    } else {
      alert("Error saving data to cloud. Check internet connection.");
    }
  }
};

export const deleteItem = async (collectionName: string, id: string) => {
  try {
    await deleteDoc(doc(db, collectionName, id));
  } catch (e) {
    console.error("Error deleting item:", e);
  }
};

// Specific Wrappers
export const dbSaveService = (service: Service) => saveItem(SERVICES_COL, service);
export const dbDeleteService = (id: string) => deleteItem(SERVICES_COL, id);

export const dbSaveExpense = (expense: Expense) => saveItem(EXPENSES_COL, expense);
export const dbDeleteExpense = (id: string) => deleteItem(EXPENSES_COL, id);

export const dbSaveBill = (bill: Bill) => saveItem(BILLS_COL, bill);
export const dbDeleteBill = (id: string) => deleteItem(BILLS_COL, id);

export const dbSaveAppointment = (appt: Appointment) => saveItem(APPOINTMENTS_COL, appt);
export const dbDeleteAppointment = (id: string) => deleteItem(APPOINTMENTS_COL, id);

export const dbSaveCompany = (company: Company) => {
  saveItem(SETTINGS_COL, { ...company, id: COMPANY_DOC });
};