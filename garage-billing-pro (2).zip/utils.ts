import { Service } from "./types";

export const fmt = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', minimumFractionDigits: 2 }).format(n || 0);

export const uid = (prefix = 'id') => prefix + '-' + Math.random().toString(36).slice(2, 9);

export const today = () => new Date().toISOString().slice(0, 10);

export const initials = (name: string) => (name || '').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase() || 'GA';

// Fuzzy matching algorithm
export function calculateSimilarity(str1: string, str2: string): number {
  if (!str1 || !str2) return 0;
  const s1 = str1.toLowerCase().replace(/\s+/g, '');
  const s2 = str2.toLowerCase().replace(/\s+/g, '');

  // Exact match
  if (s1 === s2) return 100;

  // Contains match
  if (s1.includes(s2) || s2.includes(s1)) return 80;

  // Calculate Levenshtein-like similarity
  let matches = 0;
  const minLen = Math.min(s1.length, s2.length);
  const maxLen = Math.max(s1.length, s2.length);

  // Count matching characters in order
  let i = 0, j = 0;
  while (i < s1.length && j < s2.length) {
    if (s1[i] === s2[j]) {
      matches++;
      i++;
      j++;
    } else {
      // Try to find next match
      const nextInS2 = s2.indexOf(s1[i], j);
      if (nextInS2 !== -1) {
        matches += 0.5;
        j = nextInS2 + 1;
        i++;
      } else {
        i++;
      }
    }
  }

  // Calculate percentage
  const similarity = (matches / maxLen) * 100;

  // Bonus for common substrings
  let commonSubstr = 0;
  for (let len = 3; len <= minLen; len++) {
    for (let k = 0; k <= s1.length - len; k++) {
      const substr = s1.substr(k, len);
      if (s2.includes(substr)) {
        commonSubstr += len;
      }
    }
  }
  const substrBonus = (commonSubstr / (maxLen * maxLen)) * 20;

  return Math.min(100, similarity + substrBonus);
}

export function findBestServiceMatch(transcript: string, services: Service[]): { match: Service, score: number } | null {
  if (!transcript || !services || services.length === 0) return null;

  const normalized = transcript.trim().toLowerCase();
  let bestMatch: Service | null = null;
  let bestScore = 0;

  services.forEach(service => {
    // Check Tamil name
    const taScore = calculateSimilarity(normalized, service.nameTa || '');
    // Check French name
    const frScore = calculateSimilarity(normalized, service.nameFr || '');
    // Check partial matches in Tamil
    const taPartial = (service.nameTa || '').toLowerCase().split(/\s+/).some(word =>
      word.length >= 3 && (normalized.includes(word) || word.includes(normalized))
    );
    // Check partial matches in French
    const frPartial = (service.nameFr || '').toLowerCase().split(/\s+/).some(word =>
      word.length >= 3 && (normalized.includes(word) || word.includes(normalized))
    );

    const score = Math.max(taScore, frScore) + (taPartial ? 15 : 0) + (frPartial ? 15 : 0);

    if (score > bestScore && score >= 30) { // Minimum threshold
      bestScore = score;
      bestMatch = service;
    }
  });

  return bestMatch ? { match: bestMatch, score: bestScore } : null;
}